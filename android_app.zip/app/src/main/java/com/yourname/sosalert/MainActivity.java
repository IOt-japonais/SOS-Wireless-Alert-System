package com.yourname.sosalert;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "SOS_MAIN";
    private TextView tvToken;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvToken  = findViewById(R.id.tvToken);
        tvStatus = findViewById(R.id.tvStatus);
        Button btnCopy = findViewById(R.id.btnCopy);

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{ Manifest.permission.POST_NOTIFICATIONS }, 100);
            }
        }

        // Fetch FCM token and display it
        tvStatus.setText("Fetching token...");
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                Log.w(TAG, "FCM token fetch failed", task.getException());
                tvStatus.setText("Token fetch failed. Check google-services.json");
                return;
            }
            String token = task.getResult();
            Log.d(TAG, "FCM Token: " + token);
            tvToken.setText(token);
            tvStatus.setText("Ready — waiting for SOS...");
        });

        // Copy token to clipboard
        btnCopy.setOnClickListener(v -> {
            String token = tvToken.getText().toString();
            if (!token.isEmpty() && !token.equals("Loading...")) {
                ClipboardManager clipboard =
                    (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("FCM Token", token);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(this, "Token copied!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,
                    "Notification permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                    "Notification permission denied — alerts won't show!",
                    Toast.LENGTH_LONG).show();
            }
        }
    }
}
