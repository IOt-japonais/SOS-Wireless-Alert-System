package com.yourname.sosalert;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Recreate notification channel after device reboot
        SOSFirebaseMessagingService.createNotificationChannel(context);
    }
}
