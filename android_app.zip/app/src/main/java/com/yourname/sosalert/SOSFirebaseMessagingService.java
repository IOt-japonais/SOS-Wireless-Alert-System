package com.yourname.sosalert;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class SOSFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG          = "SOS_FCM";
    private static final String CHANNEL_ID   = "SOS_CHANNEL";
    private static final String CHANNEL_NAME = "SOS Alerts";
    private static final int    NOTIF_ID     = 1001;

    // ── Called when FCM message arrives ──────────────────────────
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Log.d(TAG, "SOS message received from: " + remoteMessage.getFrom());

        String title  = "!! SOS ALERT !!";
        String body   = "Emergency signal received!";

        // Pull notification fields
        if (remoteMessage.getNotification() != null) {
            if (remoteMessage.getNotification().getTitle() != null)
                title = remoteMessage.getNotification().getTitle();
            if (remoteMessage.getNotification().getBody() != null)
                body  = remoteMessage.getNotification().getBody();
        }

        // Pull data fields sent by ESP32
        if (remoteMessage.getData().containsKey("fromId")) {
            String fromId = remoteMessage.getData().get("fromId");
            body = "SOS from node " + fromId;
            Log.d(TAG, "SOS from node ID: " + fromId);
        }

        // Ensure notification channel exists
        createNotificationChannel(this);

        // Fire all alerts
        playAlertSound();
        vibratePhone();
        showNotification(title, body);
    }

    // ── Called when FCM assigns a new device token ────────────────
    @Override
    public void onNewToken(String token) {
        Log.d(TAG, "New FCM token: " + token);
        // Copy this from Logcat → paste as FCM_DEVICE_TOKEN in ESP32 sketch
    }

    // ── Play loud alarm sound ─────────────────────────────────────
    private void playAlertSound() {
        try {
            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }

            MediaPlayer mp = new MediaPlayer();
            mp.setDataSource(getApplicationContext(), alarmUri);
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setLooping(false);
            mp.prepare();
            mp.start();

            // Auto-release when done
            mp.setOnCompletionListener(MediaPlayer::release);

        } catch (Exception e) {
            Log.e(TAG, "Sound playback error: " + e.getMessage());
        }
    }

    // ── Vibrate phone in SOS pattern (... --- ...) ────────────────
    private void vibratePhone() {
        Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator == null) return;

        // Pattern: [delay, vibrate, pause, vibrate, pause, vibrate] ms
        long[] pattern = { 0, 300, 150, 300, 150, 300,   // S (. . .)
                           300, 600, 150, 600, 150, 600,  // O (- - -)
                           300, 300, 150, 300, 150, 300 };// S (. . .)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, -1));
        } else {
            vibrator.vibrate(pattern, -1);
        }
    }

    // ── Show heads-up / lock-screen notification ──────────────────
    private void showNotification(String title, String body) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE
        );

        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(this, CHANNEL_ID)
                        .setSmallIcon(android.R.drawable.ic_dialog_alert)
                        .setContentTitle(title)
                        .setContentText(body)
                        .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                        .setPriority(NotificationCompat.PRIORITY_MAX)
                        .setCategory(NotificationCompat.CATEGORY_ALARM)
                        .setSound(soundUri)
                        .setVibrate(new long[]{ 0, 300, 150, 300, 150, 300 })
                        .setAutoCancel(true)
                        .setContentIntent(pendingIntent)
                        .setFullScreenIntent(pendingIntent, true); // shows on lock screen

        NotificationManager manager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(NOTIF_ID, builder.build());
    }

    // ── Create notification channel (required Android 8+) ─────────

    // ── Create notification channel (required Android 8+) ─────────
    public static void createNotificationChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();

            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("SOS emergency alerts from ATtiny85 node");
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{ 0, 300, 150, 300 });
            channel.setSound(soundUri, audioAttributes);
            channel.enableLights(true);

            NotificationManager manager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            manager.createNotificationChannel(channel);
        }
    }
}
